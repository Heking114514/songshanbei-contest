// Generated exact BSHD stride dispatcher. Each child owns its validation and HIP modules.
#if defined(_WIN32) && (!defined(_WIN32_WINNT) || _WIN32_WINNT < 0x0600)
#undef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#include "h3_flash_abi.h"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <new>
#include <stdexcept>
#include <string>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <mutex>
#include <dlfcn.h>
#endif
namespace {
struct Library { const char *file, *build; };
const Library libraries[] = { {"05d78dddba8d4c8a0a8e90e99cceee19654cf44056e7639aedb76c5a3310eefe.so","f166da5ed441f920d5282adc14ee875e2c9c2956707a8beb60478b9c48f6a607"},
{"52b5c1d63ae7d7e32de3e879ed9abec44df90cc07b67bae3b8d323a446675c5c.so","bfc72ea6a6abf0938ee8c4afa21baa198aaf3a2068acbf138d0b6d876b11d6b0"},
{"5483cbbcd8adb422642f352caa60b2d3959e2576b38e11e6c557f24dea2dc3dc.so","54e8effbb4d0e79e54ae22251babc88571ce0fbd3aad33fa15a32d79fbfe88b9"},
{"6e4f88d744b6718199cc1baad9f6f91d6baedf967be39b774c7bfd7a900e4051.so","ebe5215e55f6834138a9e9c1186900bc1ef55a8a884fb00598bc4a7d94bfce20"},
{"dd980060e34356552b44bfa38edabda2a69c1348e364207a59f632e1c5e927aa.so","aa55d7f59eddabf11f7674d0d524cd7a5ca0bc106a5ae63d455287dbc09adce7"} };
struct Rule { H3FlashSpec spec; size_t child; };
const Rule rules[] = { {{1,65,33,7,{{58240,896,128,1},{29568,896,128,1},{29568,896,128,1},{58240,896,128,1}}},1},
{{1,65,33,7,{{174720,2688,128,1},{88704,2688,128,1},{88704,2688,128,1},{116480,1792,128,1}}},3},
{{1,2048,2048,7,{{1835008,896,128,1},{1835008,896,128,1},{1835008,896,128,1},{1835008,896,128,1}}},0},
{{1,2048,2048,7,{{5505024,2688,128,1},{5505024,2688,128,1},{5505024,2688,128,1},{3670016,1792,128,1}}},0},
{{1,27570,27570,7,{{24702720,896,128,1},{24702720,896,128,1},{24702720,896,128,1},{24702720,896,128,1}}},2},
{{1,27570,27570,7,{{74108160,2688,128,1},{74108160,2688,128,1},{74108160,2688,128,1},{49405440,1792,128,1}}},2},
{{1,65,33,7,{{58240,896,128,1},{29568,896,128,1},{88704,2688,128,1},{58240,896,128,1}}},0},
{{1,708,708,7,{{634368,896,128,1},{634368,896,128,1},{1903104,2688,128,1},{634368,896,128,1}}},0},
{{1,27570,27570,7,{{24702720,896,128,1},{24702720,896,128,1},{74108160,2688,128,1},{24702720,896,128,1}}},4} };
int module_anchor;
std::string directory() {
    char buffer[32768] = {};
#ifdef _WIN32
    HMODULE self = nullptr;
    if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           reinterpret_cast<LPCSTR>(&module_anchor), &self) ||
        !GetModuleFileNameA(self, buffer, sizeof(buffer))) throw std::runtime_error("module path");
    std::string path(buffer);
#else
    Dl_info info{};
    if (!dladdr(&module_anchor, &info) || !info.dli_fname) throw std::runtime_error("module path");
    std::string path(info.dli_fname);
#endif
    auto slash = path.find_last_of("/\\");
    if (slash == std::string::npos) throw std::runtime_error("absolute module path required");
    return path.substr(0,slash+1);
}
const H3FlashApi *load(size_t index) {
    // Process lifetime, including on failure. Never unload HIP code used by a graph.
#ifdef _WIN32
    static SRWLOCK mutex = SRWLOCK_INIT;
    struct Guard {
        SRWLOCK *p;
        explicit Guard(SRWLOCK *p):p(p){AcquireSRWLockExclusive(p);}
        ~Guard(){ReleaseSRWLockExclusive(p);}
    } lock(&mutex);
#else
    static std::mutex mutex;
    std::lock_guard<std::mutex> lock(mutex);
#endif
    static const H3FlashApi *loaded[sizeof(libraries)/sizeof(libraries[0])] = {};
    if (loaded[index]) return loaded[index];
    auto path = directory()+libraries[index].file;
#ifdef _WIN32
    auto handle = LoadLibraryA(path.c_str());
    auto get = handle ? reinterpret_cast<H3FlashGetApi>(GetProcAddress(handle,"h3FlashGetApi")) : nullptr;
#else
    auto handle = dlopen(path.c_str(), RTLD_NOW|RTLD_LOCAL);
    auto get = handle ? reinterpret_cast<H3FlashGetApi>(dlsym(handle,"h3FlashGetApi")) : nullptr;
#endif
    if (!get) throw std::runtime_error("child load failed: "+path);
    auto api=get();
    if (!api || api->abi_version!=H3_FLASH_ABI_VERSION || api->struct_bytes!=sizeof(H3FlashApi) ||
        !api->arch || std::strcmp(api->arch,"gfx936") || !api->build_id ||
        std::strcmp(api->build_id,libraries[index].build) || !api->prepare || !api->launch || !api->destroy)
        throw std::runtime_error("child ABI/build mismatch");
    loaded[index]=api;
    return api;
}
bool equal(const H3FlashSpec &a, const H3FlashSpec &b) {
    if (a.batch!=b.batch || a.query_tokens!=b.query_tokens || a.key_tokens!=b.key_tokens || a.heads!=b.heads)
        return false;
    for (int t=0;t<4;++t) for(int i=0;i<4;++i) if(a.strides[t][i]!=b.strides[t][i]) return false;
    return true;
}
void log_plan(const H3FlashSpec &spec,size_t choice,bool matched) {
    static std::atomic_flag mutex=ATOMIC_FLAG_INIT;
    while(mutex.test_and_set(std::memory_order_acquire)) {}
    static H3FlashSpec seen[64]{};
    static size_t count=0;
    bool first=true;
    for(size_t i=0;i<count;++i) if(equal(seen[i],spec)){first=false;break;}
    if(first && count<64) seen[count++]=spec;
    else if(count>=64) first=false;
    mutex.clear(std::memory_order_release);
    if(!first)return;
    // One line per distinct layout. Old q/kv-only logs cannot recover exact dispatch keys.
    char text[2048];
    int used=std::snprintf(text,sizeof(text),
        "H3_FLASH_DISPATCH b=%lld q=%lld k=%lld heads=%lld route=%s child=%s strides=",
        (long long)spec.batch,(long long)spec.query_tokens,(long long)spec.key_tokens,
        (long long)spec.heads,matched?"measured":"baseline-unmeasured",libraries[choice].build);
    for(int t=0;t<4;++t)for(int axis=0;axis<4;++axis)
        used+=std::snprintf(text+used,sizeof(text)-used,"%s%lld",t||axis?",":"",
                           (long long)spec.strides[t][axis]);
    std::fprintf(stderr,"%s\n",text);
}
struct Plan { const H3FlashApi *api; void *child=nullptr; };
int prepare(const H3FlashSpec *spec,void **output) {
    if (!spec || !output) return 1;
    *output=nullptr;
    try {
        size_t choice=0;
        bool matched=false;
        for(const auto &r:rules) if(equal(r.spec,*spec)) {choice=r.child;matched=true;break;}
        auto api=load(choice);
        auto p=new(std::nothrow) Plan{api,nullptr};
        if(!p) return 2;
        int rc=api->prepare(spec,&p->child);
        if(rc || !p->child) {if(p->child)api->destroy(p->child);delete p;return rc?rc:3;}
        *output=p;
        log_plan(*spec,choice,matched);
        return 0;
    } catch(const std::exception &e) {std::fprintf(stderr,"H3_FLASH_DISPATCH_ERROR %s\n",e.what());return 4;}
      catch(...) {return 5;}
}
int launch(void *plan,const H3FlashCall *call,void *stream) {
    if(!plan || !call)return 1;
    auto p=static_cast<Plan*>(plan);
    return p->api->launch(p->child,call,stream);
}
void destroy(void *plan) {
    if(!plan)return;
    auto p=static_cast<Plan*>(plan);p->api->destroy(p->child);delete p;
}
const H3FlashApi api={H3_FLASH_ABI_VERSION,sizeof(H3FlashApi),"gfx936","phase9-dispatch-da28552ea00e36ebce570e7d",prepare,launch,destroy};
}
#ifdef _WIN32
#define H3_EXPORT __declspec(dllexport)
#else
#define H3_EXPORT __attribute__((visibility("default")))
#endif
extern "C" H3_EXPORT const H3FlashApi *h3FlashGetApi(){return &api;}
