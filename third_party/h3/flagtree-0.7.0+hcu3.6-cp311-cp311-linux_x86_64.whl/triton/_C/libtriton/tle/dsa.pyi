from __future__ import annotations
import triton._C.libtriton.ir
__all__: list[str] = ['load_dialects']
def load_dialects(arg0: triton._C.libtriton.ir.context) -> None:
    ...
