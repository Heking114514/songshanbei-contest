from __future__ import annotations
import triton._C.libtriton.ir
import triton._C.libtriton.llvm
__all__: list[str] = ['parse_llvm_ir']
def parse_llvm_ir(arg0: str, arg1: triton._C.libtriton.llvm.context, arg2: triton._C.libtriton.ir.context) -> triton._C.libtriton.ir.module:
    ...
