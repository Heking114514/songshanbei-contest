from __future__ import annotations
import triton._C.libtriton.ir
__all__: list[str] = ['DSLRegionOp', 'YieldOp']
class DSLRegionOp:
    def dump(self) -> None:
        ...
    def get_results(self) -> list[triton._C.libtriton.ir.op_result]:
        ...
class YieldOp:
    def dump(self) -> None:
        ...
