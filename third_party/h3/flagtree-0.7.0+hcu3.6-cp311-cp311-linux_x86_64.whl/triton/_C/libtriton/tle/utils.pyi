from __future__ import annotations
import triton._C.libtriton.ir
import triton._C.libtriton.tle.attr
import typing
__all__: list[str] = ['verify_signal', 'verify_signal_wait']
def verify_signal(kind: triton._C.libtriton.tle.attr.SignalOpKind, value: triton._C.libtriton.ir.value | None = None, scope: triton._C.libtriton.tle.attr.SyncScope = ...) -> None:
    """
    Validate a signal op's (kind, value, scope) combination; returns an error message or None
    """
def verify_signal_wait(kind: triton._C.libtriton.tle.attr.SignalWaitKind, target: triton._C.libtriton.ir.value | None = None, order: triton._C.libtriton.tle.attr.MemoryOrder = ...) -> None:
    """
    Validate a signal_wait op's (kind, target, order) combination; returns an error message or None
    """
