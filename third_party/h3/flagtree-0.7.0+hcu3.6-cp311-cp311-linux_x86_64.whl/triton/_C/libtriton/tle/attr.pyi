from __future__ import annotations
import typing
__all__: list[str] = ['FlagCXCoopKind', 'FlagCXTeamKind', 'MemoryOrder', 'SignalOpKind', 'SignalWaitKind', 'SyncScope']
class FlagCXCoopKind:
    """
    Members:
    
      Thread
    
      Warp
    
      Block
    """
    Block: typing.ClassVar[FlagCXCoopKind]  # value = <FlagCXCoopKind.Block: 2>
    Thread: typing.ClassVar[FlagCXCoopKind]  # value = <FlagCXCoopKind.Thread: 0>
    Warp: typing.ClassVar[FlagCXCoopKind]  # value = <FlagCXCoopKind.Warp: 1>
    __members__: typing.ClassVar[dict[str, FlagCXCoopKind]]  # value = {'Thread': <FlagCXCoopKind.Thread: 0>, 'Warp': <FlagCXCoopKind.Warp: 1>, 'Block': <FlagCXCoopKind.Block: 2>}
    @staticmethod
    def from_str(name: str) -> FlagCXCoopKind | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class FlagCXTeamKind:
    """
    Members:
    
      Intra
    
      Inter
    
      World
    """
    Inter: typing.ClassVar[FlagCXTeamKind]  # value = <FlagCXTeamKind.Inter: 1>
    Intra: typing.ClassVar[FlagCXTeamKind]  # value = <FlagCXTeamKind.Intra: 0>
    World: typing.ClassVar[FlagCXTeamKind]  # value = <FlagCXTeamKind.World: 2>
    __members__: typing.ClassVar[dict[str, FlagCXTeamKind]]  # value = {'Intra': <FlagCXTeamKind.Intra: 0>, 'Inter': <FlagCXTeamKind.Inter: 1>, 'World': <FlagCXTeamKind.World: 2>}
    @staticmethod
    def from_int(value: int) -> FlagCXTeamKind | None:
        ...
    @staticmethod
    def from_str(name: str) -> FlagCXTeamKind | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class MemoryOrder:
    """
    Members:
    
      Relaxed
    
      Acquire
    
      Release
    
      AcqRel
    """
    AcqRel: typing.ClassVar[MemoryOrder]  # value = <MemoryOrder.AcqRel: 3>
    Acquire: typing.ClassVar[MemoryOrder]  # value = <MemoryOrder.Acquire: 1>
    Relaxed: typing.ClassVar[MemoryOrder]  # value = <MemoryOrder.Relaxed: 0>
    Release: typing.ClassVar[MemoryOrder]  # value = <MemoryOrder.Release: 2>
    __members__: typing.ClassVar[dict[str, MemoryOrder]]  # value = {'Relaxed': <MemoryOrder.Relaxed: 0>, 'Acquire': <MemoryOrder.Acquire: 1>, 'Release': <MemoryOrder.Release: 2>, 'AcqRel': <MemoryOrder.AcqRel: 3>}
    @staticmethod
    def from_str(name: str) -> MemoryOrder | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SignalOpKind:
    """
    Members:
    
      Inc
    
      Add
    """
    Add: typing.ClassVar[SignalOpKind]  # value = <SignalOpKind.Add: 1>
    Inc: typing.ClassVar[SignalOpKind]  # value = <SignalOpKind.Inc: 0>
    __members__: typing.ClassVar[dict[str, SignalOpKind]]  # value = {'Inc': <SignalOpKind.Inc: 0>, 'Add': <SignalOpKind.Add: 1>}
    @staticmethod
    def from_str(name: str) -> SignalOpKind | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SignalWaitKind:
    """
    Members:
    
      Signal
    
      Shadow
    
      Counter
    """
    Counter: typing.ClassVar[SignalWaitKind]  # value = <SignalWaitKind.Counter: 2>
    Shadow: typing.ClassVar[SignalWaitKind]  # value = <SignalWaitKind.Shadow: 1>
    Signal: typing.ClassVar[SignalWaitKind]  # value = <SignalWaitKind.Signal: 0>
    __members__: typing.ClassVar[dict[str, SignalWaitKind]]  # value = {'Signal': <SignalWaitKind.Signal: 0>, 'Shadow': <SignalWaitKind.Shadow: 1>, 'Counter': <SignalWaitKind.Counter: 2>}
    @staticmethod
    def from_str(name: str) -> SignalWaitKind | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SyncScope:
    """
    Members:
    
      System
    
      Device
    
      Block
    
      Thread
    """
    Block: typing.ClassVar[SyncScope]  # value = <SyncScope.Block: 2>
    Device: typing.ClassVar[SyncScope]  # value = <SyncScope.Device: 1>
    System: typing.ClassVar[SyncScope]  # value = <SyncScope.System: 0>
    Thread: typing.ClassVar[SyncScope]  # value = <SyncScope.Thread: 3>
    __members__: typing.ClassVar[dict[str, SyncScope]]  # value = {'System': <SyncScope.System: 0>, 'Device': <SyncScope.Device: 1>, 'Block': <SyncScope.Block: 2>, 'Thread': <SyncScope.Thread: 3>}
    @staticmethod
    def from_str(name: str) -> SyncScope | None:
        ...
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
