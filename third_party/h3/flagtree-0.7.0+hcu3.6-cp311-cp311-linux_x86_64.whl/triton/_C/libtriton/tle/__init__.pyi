from __future__ import annotations
import triton._C.libtriton.ir
from . import attr
from . import dsa
from . import ir
from . import llvm
from . import passes
from . import raw_ir
from . import raw_passes
from . import utils
__all__: list[str] = ['attr', 'dsa', 'ir', 'is_common_ir_enabled', 'llvm', 'load_dialects', 'passes', 'raw_ir', 'raw_passes', 'utils']
def is_common_ir_enabled() -> bool:
    ...
def load_dialects(arg0: triton._C.libtriton.ir.context) -> None:
    ...
