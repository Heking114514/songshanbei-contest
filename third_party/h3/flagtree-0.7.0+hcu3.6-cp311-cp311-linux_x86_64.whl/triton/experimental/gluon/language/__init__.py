# Copyright 2018-2020 Philippe Tillet
# Copyright 2020-2022 OpenAI
# Copyright 2025-     FlagOS Contributors
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ._core import (
    base_value,
    base_type,
    block_type,
    broadcast,
    cast,
    constexpr,
    dtype,
    void,
    int1,
    int8,
    int16,
    int32,
    int64,
    uint8,
    uint16,
    uint32,
    uint64,
    float8e5,
    float8e5b16,
    float8e4nv,
    float8e4b8,
    float8e4b15,
    float16,
    bfloat16,
    float32,
    float64,
    pointer_type,
    shared_memory_descriptor,
    tensor,
    tuple,
    tuple_type,
    _unwrap_if_constexpr,
    # API Functions
    add,
    allocate_shared_memory,
    arange,
    associative_scan,
    assume,
    atomic_add,
    atomic_and,
    atomic_cas,
    atomic_max,
    atomic_min,
    atomic_or,
    atomic_xchg,
    atomic_xor,
    bank_conflicts,
    convert_layout,
    device_assert,
    device_print,
    dot_fma,
    expand_dims,
    full,
    fp4_to_fp,
    gather,
    num_warps,
    num_ctas,
    histogram,
    inline_asm_elementwise,
    join,
    load,
    map_elementwise,
    max_constancy,
    max_contiguous,
    maximum,
    minimum,
    mul,
    multiple_of,
    num_programs,
    permute,
    program_id,
    reduce,
    reshape,
    distributed_type,
    shared_memory_descriptor_type,
    set_auto_layout,
    split,
    static_assert,
    static_print,
    static_range,
    store,
    sub,
    thread_barrier,
    to_linear_layout,
    to_tensor,
    warp_specialize,
    where,
)
from ._layouts import (
    AutoLayout,
    BlockedLayout,
    SliceLayout,
    DistributedLinearLayout,
    DotOperandLayout,
    NVMMADistributedLayout,
    NVMMASharedLayout,
    SwizzledSharedLayout,
    PaddedSharedLayout,
    SharedLinearLayout,
    CoalescedLayout,
)
from ._math import (
    umulhi,
    exp,
    exp2,
    fma,
    log,
    log2,
    cos,
    rsqrt,
    sin,
    sqrt,
    sqrt_rn,
    abs,
    fdiv,
    div_rn,
    erf,
    floor,
    ceil,
)
from ._standard import (
    cdiv,
    full_like,
    max,
    min,
    ravel,
    reduce_or,
    sum,
    xor_sum,
    zeros,
    zeros_like,
)

from . import nvidia
from . import amd
from . import extra
